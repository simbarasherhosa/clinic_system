public class User {
    public String username;
    public String rank;
    public String password;
}
